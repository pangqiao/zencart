<?php 
  $za_contents[] = array('text' => UN_BOX_WISHLISTS, 'link' => zen_href_link(UN_FILENAME_WISHLISTS, '', 'NONSSL'));