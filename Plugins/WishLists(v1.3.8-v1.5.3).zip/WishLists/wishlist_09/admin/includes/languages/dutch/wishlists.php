<?php 

define('HEADING_TITLE', 'Wishlists');

define('TABLE_HEADING_WISHLIST', 'Wishlist Name');
define('TABLE_HEADING_CUSTOMER','Customer');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TABLE_HEADING_COUNT', 'Products');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_NO_RECORDS', 'No records found.');

?>