<?php 
define('UN_BOX_WISHLISTS', 'Wishlists');