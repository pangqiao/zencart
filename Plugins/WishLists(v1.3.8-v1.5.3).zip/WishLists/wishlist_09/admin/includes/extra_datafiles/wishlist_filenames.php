<?php
// Wishlist
define('UN_FILENAME_WISHLIST', 'wishlist');
define('UN_FILENAME_WISHLISTS', 'wishlists');

define('BOX_CONFIGURATION_ZCA_WISHLIST', 'Wish List Module');