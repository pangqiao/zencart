contents have moved to readme folder, open wishlist_readme.html from that folder
 