<?php

// Wishlist
define('UN_FILENAME_WISHLIST', 'wishlist');
define('UN_FILENAME_WISHLIST_S', 'wishlist_s');
define('UN_FILENAME_WISHLIST_EMAIL', 'wishlist_email');
define('UN_FILENAME_WISHLIST_FIND', 'wishlist_find');
define('UN_FILENAME_WISHLIST_EDIT', 'wishlist_edit');
define('UN_FILENAME_WISHLISTS', 'wishlists');
define('UN_FILENAME_WISHLIST_MOVE', 'wishlist_move');

?>