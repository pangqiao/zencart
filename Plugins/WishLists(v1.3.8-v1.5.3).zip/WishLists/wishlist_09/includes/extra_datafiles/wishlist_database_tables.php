<?php

// Wishlist
define('UN_TABLE_WISHLISTS', DB_PREFIX . 'un_wishlists');
define('UN_TABLE_PRODUCTS_TO_WISHLISTS', DB_PREFIX . 'un_products_to_wishlists');

?>