<?php 

define('NAVBAR_TITLE', 'Verplaats artikelen');

define('HEADING_TITLE', 'Verplaats artikelen');

define('TEXT_DESCRIPTION', 'Verplaats hier desgewenst artikelen van het ene naar het andere verlanglijstje.');

define('TEXT_LISTING_TYPE', 'Artikelen');
define('LABEL_MOVETO', 'Verplaats geselecteerde artikelen naar: ');
define('TEXT_SELECT', 'Selecteer');

?>
