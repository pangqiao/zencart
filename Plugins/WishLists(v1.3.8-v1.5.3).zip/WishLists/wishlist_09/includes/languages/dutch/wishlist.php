<?php 

define('NAVBAR_TITLE', 'Verlanglijstje');

define('HEADING_TITLE', 'Verlanglijstje');

define('TEXT_DESCRIPTION', 'Het verlanglijstje geeft je snel toegang tot artikelen die voor jou interessant zijn.');

define('TEXT_LISTING_TYPE', 'Artikelen');

?>
