<?php 

define('NAVBAR_TITLE', 'Verlanglijstje');

define('HEADING_TITLE', 'Verlanglijstje');

define('TEXT_DESCRIPTION', 'Selecteer verlanglijstje om te bewerken.');

define('TEXT_NO_RECORDS', 'Geen artikelen gevonden.');

define('TEXT_LISTING_TYPE', 'Verlanglijstjes');
define('TEXT_YES', 'Ja');
define('TEXT_NO', 'Nee');
define('TEXT_TOGGLE', 'Aan of Uit');
define('TEXT_MAKE_DEFAULT', 'Maak dit mijn standaard verlanglijstje');
define('TEXT_MAKE_PUBLIC', 'Maak dit verlanglijstje openbaar');
define('TEXT_MAKE_PRIVATE', 'Maak dit verlanglijstje prive');
define('TEXT_MOVE', 'Verplaats');
define('TEXT_ACTION_DELIMITER', ' -- ');

define('TABLE_HEADING_NAME', 'Naam');
define('TABLE_HEADING_COMMENT', 'Commentaar');
define('TABLE_HEADING_PUBLIC', 'Openbaar');
define('TABLE_HEADING_DEFAULT', 'Standaard lijstje');
define('TABLE_HEADING_ITEMS', 'Aantal artikelen');

?>
