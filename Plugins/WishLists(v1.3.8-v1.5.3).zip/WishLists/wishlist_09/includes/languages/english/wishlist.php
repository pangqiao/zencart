<?php 
define('NAVBAR_TITLE', 'Wish List');
define('HEADING_TITLE', 'Wish List');
define('TEXT_DESCRIPTION', 'The wish list allows you quick access to products you find of interest.');
define('TEXT_LISTING_TYPE', 'Products');