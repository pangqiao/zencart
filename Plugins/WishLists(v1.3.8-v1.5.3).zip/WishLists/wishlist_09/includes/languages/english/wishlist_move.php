<?php 

define('NAVBAR_TITLE', 'Move Items');

define('HEADING_TITLE', 'Move Items');

define('TEXT_DESCRIPTION', 'Use this page to move items from one wishlist to another.');

define('TEXT_LISTING_TYPE', 'Products');
define('LABEL_MOVETO', 'Move selected items to');
define('TEXT_SELECT', 'Select One');

?>
