<?php 

define('NAVBAR_TITLE', 'Wish Lists');

define('HEADING_TITLE', 'Wish Lists');

define('TEXT_DESCRIPTION', 'Select a Wish List to edit.');

define('TEXT_NO_RECORDS', 'No records found.');

define('TEXT_LISTING_TYPE', 'Wishlists');
define('TEXT_YES', 'Yes');
define('TEXT_NO', 'No');
define('TEXT_TOGGLE', 'Toggle');
define('TEXT_MAKE_DEFAULT', 'Make this my default Wishlist');
define('TEXT_MAKE_PUBLIC', 'Make this wishlist Public');
define('TEXT_MAKE_PRIVATE', 'Make this wishlist Private');
define('TEXT_MOVE', 'Move');
define('TEXT_ACTION_DELIMITER', ' -- ');

define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_COMMENT', 'Comment');
define('TABLE_HEADING_PUBLIC', 'Public');
define('TABLE_HEADING_DEFAULT', 'Default');
define('TABLE_HEADING_ITEMS', 'Items');

?>
