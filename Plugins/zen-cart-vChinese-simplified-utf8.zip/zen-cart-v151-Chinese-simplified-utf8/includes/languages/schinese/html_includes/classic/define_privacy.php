<p><strong>隐私声明模板样本 ...</strong></p>
<p>在管理页面->工具->页面编辑下修改本段文字。</p>
<p>本文件位于<code> /languages/schinese/html_includes/classic/</code></p>
<p><strong>提示: 备份<code>/languages/schinese/html_includes/your_template</code>中的文件</strong></p>