<?php
/**
 * @package admin
 * @copyright Copyright 2003-2012 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Tue Jul 17 22:56:16 2012 -0400 Modified in v1.5.1 $
 */

  define('HEADING_TITLE', '客户推荐分析');
  define('TEXT_INFO_SELECT_REFERRAL','选择一个推荐/优惠券代码');
  define('TEXT_REFERRAL_UNKNOWN', '未知');
  define('TEXT_INFO_START_DATE', '开始日期 (年-月-日)');
  define('TEXT_INFO_END_DATE', '结束日期 (年-月-日)');
  define('TEXT_ORDER_NUMBER', '订单号');
  define('TEXT_COUPON_ID', '优惠券');
