Backup ZC Version 1.1
Zen Cart Version: v1.5x (NOT BACKWARDS COMPATIBLE)
Created: May 8, 2010
Updated: April 27, 2012
Author: SkipWater skip@ccssinc.net

Released under the GNU General Public License

DISCLAIMER:
-----------------------------------------------------------------------------------------
THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, OR OTHERWISE. BY USING THIS SOFTWARE, YOU ACCEPT THE
ENTIRE RISK. I SHALL BE NOT LIABLE FOR ANY DIRECT OR INDIRECT DAMAGE,
INCLUDING DAMAGE FOR ANY DATA OR INFORMATION WHICH MAY BE LOST.

NOTES:
-----------------------------------------------------------------------------------------
BackUp ZC has many options in what is backup where and how.

The speed and size of the backups are based on the server that this script is running on.

Creating Archive on Server:
BackUp ZC grabs 512MB of memory for php and this will give you a 150M Zip file without any errors.
If you are creating the archives on your severe you should use FTP to download them and then remove
the archive from your server. This will keep down the size of your archives.

Downloading Archive from Server:
BackUp ZC grabs 512MB of memory because it will store the archive in memory. BackUp ZC downloads
the archive from memory to the users system. The reson for this is the severe might not have the required
space to store the archive file.

If you get a PHP memory error you will just receive a blank screen.
BackUp ZC will not archive empty directories.
BackUp ZC stores empty files in zip archive. WinZip will give error when extracting an empty file but
7-Zip works fine.

INSTALLATION
-----------------------------------------------------------------------------------------
Unzip backup_zc_v???.zip file to a temp area on your local computer.
Rename the YOUR_ADMIN folder to match the admin folder name that you are using on your Zen Cart site.

Upload all files from the newly renamed "admin" folder as-is to your server, retaining folder structures.

UP GRADING
-----------------------------------------------------------------------------------------
Same as install just upload new files overwriting old files.

USE
-----------------------------------------------------------------------------------------
To use, just log into the Zen Cart admin area, click on "Tools", 
and click on "BackUp ZenCart".

Note that to perform backups:

If you use your /cache folder it must be 
writable by the webserver userID. This is usually best accomlished 
by CHMOD 777 on the /cache folder, either by shell console 
or by FTP program. CHMOD777 means read/write/execute permissions.

If you use your /admin/backups folder it must be 
writable by the webserver userID. This is usually best accomlished 
by CHMOD 777 on the /admin/backups folder, either by shell console 
or by FTP program. CHMOD777 means read/write/execute permissions.

You can also download backup files by selecting Yes from the
Download Archive drop down.

NOTE: If you intend to download files, we STRONGLY recommend you do 
it only via a secure SSL / HTTPS: connection. Otherwise you put all 
your customers' data at risk if somebody is tracking your download.

ZIP FILE CONTENTS
-----------------------------------------------------------------------------------------
You should have 14 files from the zip.

your_admin/backup_zc.php
your_admin/backup_zconfig.php
your_admin/backup_zc_download.php
your_admin/includes/classes/archive.php
your_admin/includes/classes/archive_readme.txt
your_admin/includes/classes/mysql_db_backup.class.php
your_admin/includes/classes/mysql_db_backup.class_readme.txt
your_admin/includes/extra_datafiles/backup_zc.php
your_admin/includes/functions/extra_functions/backup_zc.php
your_admin/includes/languages/english/backup_zc.php
your_admin/includes/languages/english/backup_zc_download.php
uninstall_backup_zc.php
readme.txt
license.txt

TO UNINSTALL
-----------------------------------------------------------------------------------------
FTP uninstall_backup_zc.php to your Zen Cart admin folder.
In your browser after logging into your admin. Replace index.php????? with uninstall_backup_zc.php

COMMUNITY CONTRIBUTED LINK (Free Software Add Ons)
----------------------------------------------------------------------------------------- 
http://www.zen-cart.com/index.php?main_page=product_contrib_info&cPath=40_41&products_id=1646

SUPPORT THREAD
-----------------------------------------------------------------------------------------
http://www.zen-cart.com/forum/showthread.php?t=162973

CUSTOM USER SETTINGS BACKUP ZC
-----------------------------------------------------------------------------------------
All user setting are settable in the backup_zconfig.php file.

Each item in the file is comment so it should be self evident what and how to adjust 
BackUp ZC to your needs. 

HISTORY:
-----------------------------------------------------------------------------------------
Version: 1.0 May 8, 2010

Version 1.0.1 May 11, 2010
php 5.3.1 tested and running
Added Set max_allowed packet value to 64 MB to eliminate error 2006 MySQL server has gone away
Changed _GET to _POST
Added mysql_db_backup.class_readme.txt to the dist zip

Files Updated:
your_admin/backup_zc.php
your_admin/includes/classes/mysql_db_backup.class.php

Version 1.0.2 May 13, 2010
File Added
your_admin/backup_zc_download.php

Version 1.0.3 June 8, 2010
mysql backup was timing out on large data bases added time out code.

Version 1.0.4 September 7, 2010
Removed all hard coded English text in code and replace with English language definition files
your_admin/includes/languages/english/backup_zc.php
your_admin/includes/languages/english/backup_zc_download.php
(This is in hopes that non English languages will be added.)

Changed the directory listing from Zen Carts default structure to. 
Scanning your Zen Carts web site directories and display them, with there size and a option to backup.
(This added load time to BackUp ZC, but you now have the ability to backup any directory
that is in your Zen Cart web site directory tree.)

When selecting a directory for backup, the name of the directory will be added to
the archives file name for easy identification of the archives contents.

Added screen shots of BackUp ZC main page and download page.
BackUp_ZC_Main_Window.gif
BackUp_ZC_Download_Window.gif

Version 1.0.5 September 24, 2010
Added the ability to exclude multiple directories.
Added highlighted excluded directories in the backup list.
Added backup_zconfig.php file to make it easer for BackUp ZC user custom setup.

Version 1.0.6 November 26, 2010
Added if Zen Cart admin is set for ssl the downloads will be ssl.
Set gzip compression as default for sql data base file.
Added sql gzip true or false setting in backup_zconfig.php.

Version 1.0.7 December 12, 2010
Fixed when gzip selected as archive it did not delete temp file.
Rewrote function directorySize to fix Go Daddy and solve some compatibility issues.

Version 1.1 April 27, 2012
Ported to Zen Cart Version 1.5x

eof readme.txt