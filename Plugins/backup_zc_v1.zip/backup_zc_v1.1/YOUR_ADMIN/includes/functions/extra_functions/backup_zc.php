<?php
/*
 ***********************************************************************
  $Id: backup_zc.php, v 1.1 2012/27/04

  ZenCart 1.5x
  Copyright 2003-2010 Zen Cart Development Team
  Portions Copyright 2004 osCommerce
  http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0

  Written By SkipWater <skip@ccssinc.net> 04.27.2012

 ***********************************************************************
 BackUp Zen Cart uses Devin Doucette archive class to handle all the backup files
 TAR/GZIP/BZIP2/ZIP ARCHIVE CLASSES 2.1
 By Devin Doucette
 Copyright (c) 2005 Devin Doucette
 Email: darksnoopy@shaw.ca

 ***********************************************************************
 BackUp Zen Cart uses Luis Arturo Aguilar Mendoza class to handle all the MySQL backups
 MySQL DB backup class, version 1.1.0
 written by Luis Arturo Aguilar Mendoza <minibikec@prodigy.net.mx>
 Released under GNU Public license

 ***********************************************************************
*/

if (!defined('IS_ADMIN_FLAG')){
     die('Illegal Access');
    }

// BackUp ZC Version Number
$version_no = '1.1';

// $sql_formatdate = date("Y-m-d H:i:s");

if (function_exists('zen_register_admin_page')){
     if (!zen_page_key_exists('backup_zc')){ // Test if in admin pages
         // Screen activity
        echo '<h1>Installing Zen Cart BackUp ZC Version ' . $version_no . '</h1>';
        
        // ------------ Check Files ------------------
        // Check Admin Files
        if (is_file(DIR_FS_ADMIN . 'backup_zc.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'backup_zc.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'backup_zc.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }
        
        if (is_file(DIR_FS_ADMIN . 'backup_zconfig.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'backup_zconfig.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'backup_zconfig.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

        if (is_file(DIR_FS_ADMIN . 'backup_zc_download.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'backup_zc_download.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'backup_zc_download.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

        // Check Classes Files
        if (is_file(DIR_FS_ADMIN . 'includes/classes/archive.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'includes/classes/archive.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'includes/classes/archive.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }
        
        if (is_file(DIR_FS_ADMIN . 'includes/classes/mysql_db_backup.class.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'includes/classes/mysql_db_backup.class.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'includes/classes/mysql_db_backup.class.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

        // Check Extra Datafiles Files
        if (is_file(DIR_FS_ADMIN . 'includes/extra_datafiles/backup_zc.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'includes/extra_datafiles/backup_zc.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'includes/extra_datafiles/backup_zc.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

        // Check Languages Files
        if (is_file(DIR_FS_ADMIN . 'includes/languages/english/backup_zc.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'includes/languages/english/backup_zc.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'includes/languages/english/backup_zc.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

        if (is_file(DIR_FS_ADMIN . 'includes/languages/english/backup_zc_download.php')){
             // echo 'Found: '.DIR_FS_ADMIN.'includes/languages/english/backup_zc_download.php<br />';
        }else{
             echo '<b>ERROR</b> file ' . DIR_FS_ADMIN . 'includes/languages/english/backup_zc_download.php <b>DOSE NOT EXIST</b><br />';
             echo 'Check that you uploaded the file to the correct location.<br /><br />Failed Install Exiting ...<br />';
             $failed = 1;
        }

		// ------------ EOF Check Files
		if ($failed != 1){ // File Not Found ERROR
    		// Add Backup ZC to Modules menu
    		zen_register_admin_page('backup_zc', 'BOX_TOOLS_BACKUP_ZC', 'FILENAME_BACKUP_ZC', '', 'tools', 'Y', 27);
    		echo 'Added BackUp ZC Admin To Tools Menu<br />';
    		echo '______________________________________________________________________________________<br /><br />Installation Completed<br /><br />';
            // Remove this file it did its job.
            @unlink(DIR_FS_ADMIN .  'includes/functions/extra_functions/backup_zc.php');
		}else{
    		echo '<font color="RED" size="+1">You MUST FIX ERROR and try again</font><br /><br />';
    	} // EOF File Not Found ERROR
     }
}