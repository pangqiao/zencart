<?php
/*
 ***********************************************************************
  $Id: backup_zc.php, v 1.1 2012/04/27

  ZenCart 1.5x
  Copyright 2003-2010 Zen Cart Development Team
  Portions Copyright 2004 osCommerce
  http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0

  Written By SkipWater <skip@ccssinc.net> 04.27.2012

 ***********************************************************************
*/
define('FILENAME_BACKUP_ZC', 'backup_zc');
define('BOX_TOOLS_BACKUP_ZC', 'BackUp ZenCart');
?>