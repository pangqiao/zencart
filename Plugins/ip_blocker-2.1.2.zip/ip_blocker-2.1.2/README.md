ip_blocker
==========

Zen Cart:  IP Blocker v2.0.0+

Allows you to configure your Zen Cart store to block specified IP addresses from access.
