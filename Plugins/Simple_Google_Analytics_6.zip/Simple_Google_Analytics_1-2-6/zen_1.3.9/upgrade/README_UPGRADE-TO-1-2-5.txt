************************************************************
************************************************************
************************************************************
Contribution Name: Simple Google Analytics
Version Date: v 1.2.5 10/31/2011 Eric Leuenberger (Zen ID: econcepts) http://www.ecommerceamplifier.com

License: under the GPL - See attached License for info.

Designed for: Zen Cart v1.3.6 and higher. Release can be compatable with older versions as well.

Portions copyright Andrew Berezin
Portions copyright Dayne Larsen

Description: This new module version 1.2.5 enables you to integrate the Google Analytics service
             with both e-commerce tracking and Conversion Tracking capabilities as described here:
			 http://www.google.com/analytics/ using the new release of "ga.js" code (replacing the "urchin.js" version)
			 released by Google in December of '07 and documented here:
			 http://analytics.blogspot.com/2007/12/announcing-new-graphing-tools-gajs.html
			 OR by using the Asyncronous tracking code released in December of 2009 by Google documented here:
			 http://code.google.com/apis/analytics/docs/tracking/asyncTracking.html

			 
Zen Cart Support forum thread here: http://www.zen-cart.com/forum/showthread.php?t=53701

**************************************************************
************************************************************
************************************************************

------------------------------------------------------------------------------
########### Upgrading from previous 1.2.x to 1.2.5 version ##################
------------------------------------------------------------------------------


If you are running any of the very early versions (prior to 1.2.x), then it is best to simply start as if this was a "new install". A number of
items have been changed since the early stage development.

Before you do that though, take a note of (write down) your Google Analytics tracking numbers so you can re-enter them into
the admin once installation is complete.



Step 1:
++++++++
Upload the files included in the package overwriting those on your system.


Step 2: (Safe to skip this step if upgrading from 1.2.3 or higher)
++++++++
If you are upgrading from a version older than 1.2.3 then you will need to run the SQL upgrade patch. Otherwise there is no
need to run any patch and you can skip this step.

If you do need to run the patch then, apply the following SQL Patch through the Admin "UPGRADE-toversion-1-2-5.sql" (found in the package files.) 
Do NOT upload the file and try tp patch your cart. Instead, copy and paste the contents of the file
into your patch box within your Zen Cart admin and run from there.


Step 3:
++++++++

Version 1.2.5 uses a new override file is being used so there are a few lines of code you need to remove from a file (altered in previous versions) on your site.
This override file prevents the need for altering the 'html_header.php" file (as in some earlier versions.)

After uploading all files to the server do the following:

3a) Open the file found at: /includes/templates/[your_template]/common/html_header.php


3b) Find the lines that look like this just before the </head> tag and REMOVE them (delete). Save the file and re-upload to your server.

<?php
/* Begin Simple Google Analytics */
  if (in_array($current_page_base,explode(",",'popup_image,popup_image_additional,popup_cvv_help,popup_coupon_help,popup_attributes_qty_prices,popup_search_help,popup_shipping_estimator')) ) {
	//Skip outputting the tracking code as this is a pop-up window
  } else { // Print tracking code to page
	if (GOOGLE_ANALYTICS_TRACKING_TYPE == "Asynchronous") {
	require($template->get_template_dir('.php',DIR_WS_TEMPLATE, $current_page_base,'google_analytics') . '/google_analytics.php');
	}
  } // end if for page determination
/* End Simple Google Analytics */
?>



STEP 4: (Safe to skip this step if upgrading from 1.2.3 or higher)
==============

If you are upgrading from verion 1.2.3 or higher you can SKIP this step. If you are upgrading from a version that is lower thahn 1.2.3 then perform the following.


You'll need to make alterations to the previous line of code inserted in the tpl_main_page.php file.
At the bottom of /includes/templates/[your_template]/common/tpl_main_page.php (just above the closing </BODY> tag,) find the line of code that looks like this:

<?php
require($template->get_template_dir('.php',DIR_WS_TEMPLATE, $current_page_base,'google_analytics') . '/google_analytics.php');
?>

and REPLACE it with the following:

<?php
/* Begin Simple Google Analytics */
if (GOOGLE_ANALYTICS_TRACKING_TYPE == "Asynchronous") {
// Do nothing
} else {
require($template->get_template_dir('.php',DIR_WS_TEMPLATE, $current_page_base,'google_analytics') . '/google_analytics.php');
}
/* End Simple Google Analytics */
?>

