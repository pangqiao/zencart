#######################################################################
#   USE THIS FILE ONLY IF YOU ALREADY HAVE VERSION 1.2.x or higher    #
#       of "SIMPLE GOOGLE ANALYTICS" CONTRIBUTION INSTALLED           #
#     THIS UPGRADE BRINGS THOSE VERSIONS UP-TO-DATE WITH THE NEW      #
#      1.2.4 VERSION REMOVING ITEMS THAT ARE NOT USED ANYMORE AND     #
#                        ADDING NEW ITEMS     			      #
#######################################################################

SET @t4=0;
SELECT (@t4:=configuration_group_id) as t4 
FROM configuration_group
WHERE configuration_group_title= 'Google Analytics Configuration';

#UPGRADE Code Below (from 1.2.x to 1.2.4)
INSERT INTO configuration (`configuration_id`, `configuration_title`, `configuration_key`, `configuration_value`, `configuration_description`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES (NULL, 'Google Tracking Code Type To Use', 'GOOGLE_ANALYTICS_TRACKING_TYPE', 'ga.js', 'Select the type of tracking you wish to use. The default is the "ga.js" style. You have the ability to change this to either the older Urchin code or the newest Asycronous tracking code. Visit the <a href="http://code.google.com/apis/analytics/docs/tracking/home.html" target="_blank">Google Analytics Website</a> for more information on each.<br><br>For more hints and tips on how to use Google Analytics to increase sales from your store, visit <b><a href="http://www.zencartoptimization.com" target="blank">ZenCartOptimization.com</a></b><br><br><b>Select your tracking preference below</b><br>', @t4, 8, NOW(), NOW(), NULL, 'zen_cfg_select_option(array(''ga.js'', ''Urchin'', ''Asynchronous''), ');
# INSERT INTO configuration (`configuration_id`, `configuration_title`, `configuration_key`, `configuration_value`, `configuration_description`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES (NULL, 'Add Custom Tracking Before Main Analytics Code?', 'GOOGLE_ANALYTICS_CUSTOM_BEFORE', 'Disable', 'Do you want to include any custom tracking before the main tracking segment?', @t4, 9, now(), now(), NULL, 'zen_cfg_select_option(array(''Enable'', ''Disable''),'), (NULL, 'Google Custom Code - Before', 'GOOGLE_ANALYTICS_BEFORE_CODE', 'Please copy and paste or add your custom tracking here.', 'Insert custom tracking code', @t4, 10, now(), now(), NULL, 'zen_cfg_textarea(');
INSERT INTO configuration (`configuration_id`, `configuration_title`, `configuration_key`, `configuration_value`, `configuration_description`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES (NULL, 'Add Custom Tracking After Main Analytics Code?', 'GOOGLE_ANALYTICS_CUSTOM_AFTER', 'Disable', 'Do you want to include any custom tracking after the main tracking segment? This can be used to customize the tracking code to your individual needs. Adding tracking objects according to the details on the <a href="http://code.google.com/apis/analytics/docs/tracking/gaTrackingCustomVariables.html" target="_blank">Google Analytics site<a/>. ', @t4, 11, now(), now(), NULL, 'zen_cfg_select_option(array(''Enable'', ''Disable''),'), (NULL, 'Google Custom Code - After', 'GOOGLE_ANALYTICS_AFTER_CODE', 'Please copy and paste or add your custom tracking here.', 'Insert custom tracking code', @t4, 12, now(), now(), NULL, 'zen_cfg_textarea(');
#Drop previous column now unused
DELETE FROM configuration WHERE configuration_key = 'GOOGLE_URCHINTRACKING_ACTIVE';