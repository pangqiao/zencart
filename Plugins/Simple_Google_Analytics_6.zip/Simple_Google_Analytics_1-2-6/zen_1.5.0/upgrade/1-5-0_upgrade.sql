/*
zencart 1.5 mods
*/
DELETE FROM admin_pages WHERE page_key='configGoogle_Analytics';

SET @t4=0;
SELECT (@t4:=configuration_group_id) as t4 
FROM configuration_group
WHERE configuration_group_title= 'Google Analytics Configuration';

INSERT INTO admin_pages (page_key,language_key,main_page,page_params,menu_key,display_on_menu,sort_order) VALUES ('configGoogle_Analytics','BOX_CONFIGURATION_GOOGLE_ANALYTICS','FILENAME_CONFIGURATION',CONCAT('gID=',@t4), 'configuration', 'Y', @t4);
