Simple Google Analytics Module.
Please read the install.txt file for the version you are installing. 