INSERT INTO admin_pages (page_key, language_key, main_page, menu_key, display_on_menu, sort_order) VALUES ('passChange', 'BOX_TOOLS_PASSCHANGE', 'FILENAME_PASSCHANGE', 'tools', 'Y', '40');
