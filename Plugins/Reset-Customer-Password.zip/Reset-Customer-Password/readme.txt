Reset Customer Password from Admin
Version 1.6.1
Updated by: jeking, batracy
Author: lebrand2006
--------------
This plugin allows you to reset a customer password from the Admin.  You can search for a customer by their email address.

Installation
--------------
No warranties expressed or implied; use at your own risk.

1) Rename YOUR-AMDIN to that of your admin folder. There are no core file over-rides, so upload all files.
2) If you're using Zen Cart 1.5.x, run sql 'add_admin_menu_entry_v15x.sql'.  If you are using a table prefix, you MUST EDIT the sql statement or you will get an error. For example, if your table prefix is 'zen_' change 'admin_pages' to 'zen_admin_pages'.

Support
--------------
All supoport provided in the forum at
http://www.zen-cart.com/showthread.php?65871-Reset-customer-password-from-admin

Credits
3/31/2015 - batracy
	Fixed a bug in the search by customer email address, fix is only applied to 1.5.x version
--------------
2/5/2015 -  jeking
	Updated folder structure
	Re-wrote ReadMe
	Added search by customer email address

This plugin was originally done by Charis Chrisochoou
Drama - Greece forum handle lebrand2006