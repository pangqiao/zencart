<?php
define('BOX_CONFIGURATION_EDIT_ORDERS', 'Edit Orders');
