<?php
/**
 * @package general
 * @copyright Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: invoice_filenames.php 4/8/2015 mprough-PRO-Webs.net 
 * For editable admin invoice area 
 */

// DEFINTELY DON'T EDIT THIS FILE UNLESS YOU KNOW WHAT YOU ARE DOING!

// invoice Filename Defines
	define('FILENAME_INVOICE', 'invoice');
	define('FILENAME_DEFINE_INVOICE', 'define_invoice');
?>
