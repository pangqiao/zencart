<?php
/**
 * @package general
 * @copyright Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: packing_slips_filenames.php 4/8/2015 mprough-PRO-Webs.net 
 * For editable admin packing slip area 
 */

// DEFINTELY DON'T EDIT THIS FILE UNLESS YOU KNOW WHAT YOU ARE DOING!

// packing slips Filename Defines
	define('FILENAME_PACKING_SLIPS', 'packing_slips');
	define('FILENAME_DEFINE_PACKING_SLIPS', 'define_packing_slips');
?>
