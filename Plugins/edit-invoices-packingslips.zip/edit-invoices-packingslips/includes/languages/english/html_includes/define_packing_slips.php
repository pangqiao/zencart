<!--
 THIS FILE IS SAFE TO EDIT! This is the content for your new page.
 Note that the file in the template directory overrides the non-template file 

-->

<!-- bof define_packing_slips -->
	<p>Your page text goes here</p>
<!-- eof define_packing_slips -->
