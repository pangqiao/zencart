<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: packing_slips.php 4/8/2015 mprough-PRO-Webs.net 
 * For editable admin packing slip area 
 */

// DON'T EDIT THIS FILE UNLESS YOU KNOW WHAT YOU ARE DOING!

// This is used to display the heading and the navigation bar
	define('NAVBAR_TITLE', 'packing slips');
	define('HEADING_TITLE', 'packing slips');
?>
