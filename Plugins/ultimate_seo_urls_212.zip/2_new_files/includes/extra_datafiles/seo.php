<?php
define('TABLE_SEO_CACHE', DB_PREFIX . 'seo_cache');