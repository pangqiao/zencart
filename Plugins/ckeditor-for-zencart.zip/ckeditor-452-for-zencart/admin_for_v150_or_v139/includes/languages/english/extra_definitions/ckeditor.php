<?php
/**
 * @package htmleditors
 * @copyright Copyright 2010 Kuroi Web Design
 * @copyright Portions Copyright 2003-2006 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ckeditor.php 107 2010-04-28 21:28:02Z kuroi $
 */

  define('EDITOR_CKEDITOR', 'CKEditor');
