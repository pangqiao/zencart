#################################################
# USE ONLY IF your are running Zen-Cart 1.5.x.!!!
#################################################

# Register the pages for Admin Access Control
INSERT INTO admin_pages (page_key, language_key, main_page, page_params, menu_key, display_on_menu, sort_order) VALUES ('sitemapxml', 'BOX_SITEMAPXML', 'FILENAME_SITEMAPXML', '', 'tools', 'Y', 100);
